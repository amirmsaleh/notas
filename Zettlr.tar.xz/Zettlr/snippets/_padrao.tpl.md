---
title: "${1:Titulo}"
date: $CURRENT_YEAR-$CURRENT_MONTH-$CURRENT_DATE
id: $ZKN_ID
---

# ${1:Titulo}

## Ideia

$0

---

## Referências

- **Fonte:** [[ID_OU_CITAÇÃO]] (Ex: @autor2024 ou link externo)
- **Contexto:** Por que essa ideia é relevante? De onde ela surgiu?

---

## Conexões

- [[ID]]: Explique brevemente por que esta nota se conecta a esta nova (Ex: "Complementa a teoria X").
