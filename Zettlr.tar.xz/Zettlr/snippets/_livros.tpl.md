---
title: "${1:Autor (Ano)}"
id: $ZKN_ID
date: $CURRENT_YEAR-$CURRENT_MONTH-$CURRENT_DATE
citekey: "@${2:citekey}"
tags: [#literatura/processar, #${3:tema}]
---

# Referência: @${2:citekey}

## 📌 Resumo
$0

## 📝 Notas e Citações
- "$4" [@${2:citekey}, p. $5]

## 🔗 Conexões
- [[$6]]